YPSS Secure Services Website
================================
Files:
- index.html
- style.css
- script.js
- assets/ypss-brochure-cover.png

The site is a single-page, mobile-friendly business website created from the supplied YPSS brochure.
To publish free, upload these files to a static host such as GitHub Pages, Netlify, or Vercel.
